export const LANG = {
  ru: {
    search: "Найти машину",
    cheapest: "Самые дешевые",
    expensive: "Самые дорогие",
    back: "← Назад",
    cars_found: (n) => `${n} машин найдено`,
    transmission: "Трансмиссия",
    mileage: "Пробег",
    price: "Стоимость",
    examples: "Примеры цен",
    desc: "Описание",
    category: "Категория",
    auto: "Автомат",
    manual: "Механика"
  },
  en: {
    search: "Search car",
    cheapest: "Cheapest",
    expensive: "Most expensive",
    back: "← Back",
    cars_found: (n) => `${n} cars found`,
    transmission: "Transmission",
    mileage: "Mileage",
    price: "Price",
    examples: "Price examples",
    desc: "Description",
    category: "Category",
    auto: "Automatic",
    manual: "Manual"
  }
}
