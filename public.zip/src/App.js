// src/App.js
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import { jwtDecode } from "jwt-decode";
import { Box, useMediaQuery } from "@mui/material";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import CarDetail from "./pages/CarDetail";
import Login from "./components/Login";
import Register from "./components/Register";
import Account from "./components/Account";
import Footer from "./components/Footer";
import AboutOasisCar from "./components/About";
import CartPage from "./pages/CartPage";
import Footer2 from "./components/Footer_two";
import VisitorLogger from "./pages/VisitorLogger";

function App() {
  const [lang, setLang] = useState(() => localStorage.getItem("lang") || "en");
  const [user, setUser] = useState(null);
  const isMobile = useMediaQuery("(max-width:580px)");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      try {
        setUser(jwtDecode(token));
      } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("lang", lang);
  }, [lang]);

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
      }}
    >
      <BrowserRouter>
        <Navbar user={user} lang={lang} setLang={setLang} />

        <Box component="main" sx={{ flex: 1 }}>
          <Routes>
            <Route path="/" element={<Home lang={lang} />} />
            <Route path="/car/:id" element={<CarDetail lang={lang} />} />
            <Route path="/login" element={<Login setUser={setUser} lang={lang} />} />
            <Route path="/cart" element={<CartPage lang={lang} />} />
            <Route path="/register" element={<Register lang={lang} />} />
            <Route path="/account" element={<Account />} />
            <Route path="/about" element={<AboutOasisCar />} />
          </Routes>
        </Box>

        <Footer />
        {isMobile && <Footer2 />}
        <VisitorLogger  />
      </BrowserRouter>
    </Box>
  );
}

export default App;
