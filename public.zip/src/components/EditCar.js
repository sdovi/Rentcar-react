import { useState } from 'react';
import axios from 'axios';

export default function EditCar({ car, onBack, onSaved }) {
  const token = localStorage.getItem('token');

  const [formData, setFormData] = useState({
    name_ru: car.name_ru || '',
    name_en: car.name_en || '',
    description_ru: car.description_ru || '',
    description_en: car.description_en || '',
    category: car.category || '',
    is_automatic: car.is_automatic,
    price_per_day: car.price_per_day || '',
    mileage: car.mileage || '',
    pricing_examples: car.pricing_examples || '',
    new_images: []
  });

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === 'file') {
      setFormData((prev) => ({
        ...prev,
        new_images: [...prev.new_images, ...Array.from(files)]
      }));
    } else if (type === 'checkbox') {
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const removeNewImage = (index) => {
    setFormData((prev) => ({
      ...prev,
      new_images: prev.new_images.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = () => {
    const data = new FormData();
    for (let key in formData) {
      if (key !== 'new_images') {
        data.append(key, formData[key]);
      }
    }
    formData.new_images.forEach((img) => {
      data.append('images', img);
    });

    axios.put(`https://innermentorlab.com/api/user/cars/${car.id}/`, data, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data'
      }
    })
    .then(() => {
      onSaved(); // callback из Account.js
    })
    .catch((err) => {
      console.error(err.response?.data || err);
      alert('Ошибка при обновлении');
    });
  };

  return (
    <div className="edit-form">
      <h2>Редактировать автомобиль</h2>

      <input name="name_ru" value={formData.name_ru} onChange={handleChange} placeholder="Название (RU)" />
      <input name="name_en" value={formData.name_en} onChange={handleChange} placeholder="Название (EN)" />
      <textarea name="description_ru" value={formData.description_ru} onChange={handleChange} placeholder="Описание (RU)" />
      <textarea name="description_en" value={formData.description_en} onChange={handleChange} placeholder="Описание (EN)" />
      <input name="price_per_day" value={formData.price_per_day} onChange={handleChange} placeholder="Цена" />
      <input name="mileage" value={formData.mileage} onChange={handleChange} placeholder="Пробег" />
      <textarea name="pricing_examples" value={formData.pricing_examples} onChange={handleChange} placeholder="Примеры цен" />

      <select name="category" value={formData.category} onChange={handleChange}>
        <option value="">Категория</option>
        <option value="Без депозита">Без депозита</option>
        <option value="Эконом">Эконом</option>
        <option value="Стандарт">Стандарт</option>
        <option value="Бизнес">Бизнес</option>
        <option value="Люкс">Люкс</option>
        <option value="Спорт">Спорт</option>
        <option value="Электро">Электро</option>
        <option value="7 мест">7 мест</option>
      </select>

      <label className="checkbox-row">
        <input type="checkbox" name="is_automatic" checked={formData.is_automatic} onChange={handleChange} />
        Автоматическая коробка
      </label>

      <div style={{ fontSize: 14, marginBottom: 5 }}>Загрузить новые изображения:</div>
      <input type="file" name="new_images" multiple onChange={handleChange} />

      {formData.new_images.length > 0 && (
        <ul className="file-list">
          {formData.new_images.map((file, i) => (
            <li key={i}>
              {file.name}
              <button type="button" onClick={() => removeNewImage(i)}>✖</button>
            </li>
          ))}
        </ul>
      )}

      <div style={{ marginTop: 10 }}>
        <button onClick={handleSubmit}>Сохранить</button>
        <button onClick={onBack} style={{ marginLeft: 8, backgroundColor: '#ccc', color: '#333' }}>
          Назад
        </button>
      </div>
    </div>
  );
}
