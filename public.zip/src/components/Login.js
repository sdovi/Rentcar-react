// src/components/Login.jsx
import React, { useState } from "react";
import axios from "axios";
import "../style.css";
import { useNavigate } from "react-router-dom";

export default function Login({ setUser, lang }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  // Переводы всех строк
  const translations = {
    en: {
      title: "Sign In",
      emailPlaceholder: "Email",
      passwordPlaceholder: "Password",
      submit: "Sign In",
      error: "Invalid email or password",
      noAccount: "No account?",
      register: "Register",
    },
    ru: {
      title: "Вход в аккаунт",
      emailPlaceholder: "Email",
      passwordPlaceholder: "Пароль",
      submit: "Войти",
      error: "Неверный email или пароль",
      noAccount: "Нет аккаунта?",
      register: "Зарегистрироваться",
    },
    de: {
      title: "Anmeldung",
      emailPlaceholder: "E-Mail",
      passwordPlaceholder: "Passwort",
      submit: "Anmelden",
      error: "Ungültige E-Mail oder Passwort",
      noAccount: "Kein Konto?",
      register: "Registrieren",
    },
    es: {
      title: "Iniciar sesión",
      emailPlaceholder: "Correo electrónico",
      passwordPlaceholder: "Contraseña",
      submit: "Entrar",
      error: "Email o contraseña incorrectos",
      noAccount: "¿No tienes cuenta?",
      register: "Registrarse",
    },
    ar: {
      title: "تسجيل الدخول",
      emailPlaceholder: "البريد الإلكتروني",
      passwordPlaceholder: "كلمة المرور",
      submit: "دخول",
      error: "البريد أو كلمة المرور غير صحيحة",
      noAccount: "لا حساب؟",
      register: "سجل الآن",
    },
  };

  const t = translations[lang] || translations.en;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    axios
      .post("https://innermentorlab.com/api/login/", {
        username: form.email,
        password: form.password,
      })
      .then((res) => {
        localStorage.setItem("token", res.data.access);
        setUser(res.data.user);
        navigate("/account");
      })
      .catch((err) => {
        console.error(err.response?.data || err);
        setError(t.error);
        setTimeout(() => setError(""), 3000);
      });
  };

  return (
    <div className="auth-form">
      <h2>{t.title}</h2>
      <input
        name="email"
        placeholder={t.emailPlaceholder}
        onChange={handleChange}
        value={form.email}
      />
      <input
        name="password"
        type="password"
        placeholder={t.passwordPlaceholder}
        onChange={handleChange}
        value={form.password}
      />
      <button onClick={handleSubmit}>{t.submit}</button>
      {error && <div className="toast">{error}</div>}

      <p className="auth-switch">
        {t.noAccount}{" "}
        <span className="link2" onClick={() => navigate("/register")}>
          {t.register}
        </span>
      </p>
    </div>
  );
}
