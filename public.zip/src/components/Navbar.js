import React, { useState } from "react";
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Box,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Badge,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import FavoriteIcon from "@mui/icons-material/Favorite";
import { Link } from "react-router-dom";
import logo from "./logo.png";
import "../style.css";
import { useCart } from "../context/CartContext";

import { useEffect } from "react";
export default function Navbar({ user }) {
  useEffect(() => {
    const handleOpenMenu = () => setMobileOpen(true);
    window.addEventListener("openNavbarMenu", handleOpenMenu);
    return () => window.removeEventListener("openNavbarMenu", handleOpenMenu);
  }, []);

  const [lang, setLangState] = useState(
    () => localStorage.getItem("lang") || "en"
  );
  const [mobileOpen, setMobileOpen] = useState(false);
  const { cartItems } = useCart();

  const handleDrawerToggle = () => setMobileOpen(!mobileOpen);

  const languageOptions = [
    { value: "en", label: "English" },
    { value: "de", label: "Deutsch" },
    { value: "ru", label: "Русский" },
    { value: "es", label: "Español" },
    { value: "ar", label: "العربية" },
  ];

  const translations = {
    en: {
      home: "Home",
      about: "About",
      account: "Account",
      login: "Login",
      favorite: "Favorites",
      languageLabel: "Language",
    },
    ru: {
      home: "Главная",
      about: "О нас",
      account: "Личный кабинет",
      login: "Вход",
      favorite: "Избранное",
      languageLabel: "Язык",
    },
    de: {
      home: "Startseite",
      about: "Über uns",
      account: "Konto",
      login: "Anmelden",
      favorite: "Favoriten",
      languageLabel: "Sprache",
    },
    es: {
      home: "Inicio",
      about: "Sobre nosotros",
      account: "Cuenta",
      login: "Iniciar sesión",
      favorite: "Favoritos",
      languageLabel: "Idioma",
    },
    ar: {
      home: "الرئيسية",
      about: "معلومات عنا",
      account: "الحساب",
      login: "تسجيل الدخول",
      favorite: "المفضلة",
      languageLabel: "اللغة",
    },
  };
  const t = translations[lang] || translations.en;

  const changeLang = (value) => {
    localStorage.setItem("lang", value);
    setLangState(value);
    window.location.reload();
  };

  const drawer = (
    <Box sx={{ width: 250, bgcolor: "#000", p: 2 }}>
      <List>
        <ListItem button component={Link} to="/" onClick={handleDrawerToggle}>
          <ListItemText
            primary={t.home}
            primaryTypographyProps={{ color: "#fff" }}
          />
        </ListItem>
        <ListItem
          button
          component={Link}
          to="/about"
          onClick={handleDrawerToggle}
        >
          <ListItemText
            primary={t.about}
            primaryTypographyProps={{ color: "#fff" }}
          />
        </ListItem>
        <ListItem
          button
          component={Link}
          to="/cart"
          onClick={handleDrawerToggle}
        >
          <ListItemText
            primary={t.favorite}
            primaryTypographyProps={{ color: "#fff" }}
          />
        </ListItem>
        {user ? (
          <ListItem
            button
            component={Link}
            to="/account"
            onClick={handleDrawerToggle}
          >
            <ListItemText
              primary={t.account}
              primaryTypographyProps={{ color: "#fff" }}
            />
          </ListItem>
        ) : (
          <ListItem
            button
            component={Link}
            to="/login"
            onClick={handleDrawerToggle}
          >
            <ListItemText
              primary={t.login}
              primaryTypographyProps={{ color: "#fff" }}
            />
          </ListItem>
        )}
      </List>
      <FormControl size="small" fullWidth sx={{ mt: 2 }}>
        <InputLabel id="lang-label-mobile" sx={{ color: "#fff" }}>
          {t.languageLabel}
        </InputLabel>
        <Select
          labelId="lang-label-mobile"
          value={lang}
          onChange={(e) => changeLang(e.target.value)}
          label={t.languageLabel}
          sx={{
            color: "#fff",
            ".MuiSelect-icon": { color: "#fff" },
            ".MuiOutlinedInput-notchedOutline": { borderColor: "#555" },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#bbb",
            },
          }}
        >
          {languageOptions.map((opt) => (
            <MenuItem key={opt.value} value={opt.value} sx={{ color: "#000" }}>
              {opt.label}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );

  return (
    <AppBar position="static" sx={{ backgroundColor: "#000", boxShadow: 1 }}>
      <Toolbar>
        <Box sx={{ display: "flex", alignItems: "center", flexGrow: 1 }}>
          <Link to="/" className="logo-link">
            <img src={logo} alt="logo" className="logo-img" />
            <Typography
              variant="h6"
              className="logo-text"
              sx={{ color: "#e60000", ml: 1 }}
            >
              RTG luxury car rental
            </Typography>
          </Link>
        </Box>
        <IconButton component={Link} to="/cart" sx={{ color: "#fff" }}>
          <Badge badgeContent={cartItems.length} color="error">
            <FavoriteIcon />
          </Badge>
        </IconButton>
        {/* Десктоп */}
        <Box
          sx={{
            display: { xs: "none", md: "flex" },
            alignItems: "center",
            gap: 2,
          }}
        >
          <Link
            to="/about"
            className="nav-about-link"
            style={{ color: "#fff" }}
          >
            {t.about}
          </Link>

          <FormControl size="small">
            <InputLabel id="lang-label" sx={{ color: "#fff" }}>
              {t.languageLabel}
            </InputLabel>
            <Select
              labelId="lang-label"
              value={lang}
              onChange={(e) => changeLang(e.target.value)}
              label={t.languageLabel}
              sx={{
                minWidth: 120,
                color: "#fff",
                ".MuiSelect-icon": { color: "#fff" },
                ".MuiOutlinedInput-notchedOutline": { borderColor: "#555" },
                "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#bbb",
                },
              }}
            >
              {languageOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          {user ? (
            <Link to="/account" className="nav-link" style={{ color: "#fff" }}>
              {t.account}
            </Link>
          ) : (
            <Link to="/login" className="nav-link" style={{ color: "#fff" }}>
              {t.login}
            </Link>
          )}

          {/* Кнопка избранного */}
          <IconButton component={Link} to="/cart" sx={{ color: "#fff" }}>
            <Badge badgeContent={cartItems.length} color="error">
              <FavoriteIcon />
            </Badge>
          </IconButton>
        </Box>

        {/* Мобильный бургер */}
        <IconButton
          edge="end"
          aria-label="menu"
          onClick={handleDrawerToggle}
          sx={{ display: { md: "none" }, color: "#fff" }}
        >
          <MenuIcon />
        </IconButton>
      </Toolbar>

      <Drawer
        anchor="right"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        PaperProps={{
          sx: {
            backgroundColor: "#000",
            color: "#fff",
          },
        }}
      >
        {drawer}
      </Drawer>
    </AppBar>
  );
}
