import React, { useEffect, useRef } from "react";
import "../style.css";
import { FaSearch } from "react-icons/fa";

const translations = {
  en: { searchPlaceholder: "Search car" },
  ru: { searchPlaceholder: "Найти машину" },
  de: { searchPlaceholder: "Auto suchen" },
  es: { searchPlaceholder: "Buscar coche" },
  ar: { searchPlaceholder: "ابحث عن سيارة" },
};

export default function SearchBar({ query, setQuery, lang }) {
  const t = translations[lang] || translations.en;
  const inputRef = useRef(null);

  useEffect(() => {
    const handleFocusSearch = () => {
      if (inputRef.current) {
        inputRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
        inputRef.current.focus();
        inputRef.current.classList.add("highlight-red");
        setTimeout(() => {
          inputRef.current.classList.remove("highlight-red");
        }, 2000);
      }
    };

    window.addEventListener("focusSearchInput", handleFocusSearch);
    return () => window.removeEventListener("focusSearchInput", handleFocusSearch);
  }, []);

  return (
    <div className="search-bar2">
      <div className="filter-container search-wrapper">
        <FaSearch className="search-icon" />
        <input
          ref={inputRef}
          type="text"
          placeholder={t.searchPlaceholder}
          className="search-input"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>
    </div>
  );
}
