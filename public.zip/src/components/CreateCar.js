import { useState, useEffect } from 'react';
import axios from 'axios';
import { Slider } from '@mui/material';

export default function CreateCar({ updateCars, setView }) {
  const [formData, setFormData] = useState({
    name_ru: '',
    name_en: '',
    description_ru: '',
    description_en: '',
    category: '',
    is_automatic: false,
    price_per_day: '',
    mileage: '',
    pricing_examples: '',
    images: [],
    city: '',
    year: 2020,
    video_360: null,
  });

  const [suggestions, setSuggestions] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [citySuggestions, setCitySuggestions] = useState([]);

  const token = localStorage.getItem('token');

  const handleChange = (e) => {
    const { name, value, type, checked, files } = e.target;
    if (type === 'file') {
      if (name === 'video_360') {
        setFormData((prev) => ({ ...prev, video_360: files[0] }));
      } else {
        setFormData((prev) => ({
          ...prev,
          images: [...prev.images, ...Array.from(files)]
        }));
      }
    } else if (type === 'checkbox') {
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleBrandInput = async (e) => {
    const value = e.target.value;
    setSearchTerm(value);
    setFormData((prev) => ({
      ...prev,
      name_ru: value,
      name_en: value
    }));
    if (value.length >= 2) {
      try {
        const res = await axios.get(`https://vpic.nhtsa.dot.gov/api/vehicles/GetMakesForVehicleType/car?format=json`);
        const brands = res.data.Results.map(b => b.MakeName);
        const filtered = brands.filter(name => name.toLowerCase().includes(value.toLowerCase()));
        setSuggestions(filtered.slice(0, 10));
        setShowSuggestions(true);
      } catch (err) {
        console.error("Error loading brands:", err);
      }
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  };

  const handleCityInput = (e) => {
    const value = e.target.value;
    setFormData((prev) => ({ ...prev, city: value }));
    if (value.length >= 2) {
      const cities = ['Moscow', 'Saint Petersburg', 'Tashkent', 'London', 'Paris', 'New York'];
      setCitySuggestions(cities.filter(c => c.toLowerCase().includes(value.toLowerCase())).slice(0, 5));
    } else {
      setCitySuggestions([]);
    }
  };

  const selectSuggestion = (value) => {
    setSearchTerm(value);
    setFormData((prev) => ({
      ...prev,
      name_ru: value,
      name_en: value
    }));
    setShowSuggestions(false);
  };

  const selectCity = (value) => {
    setFormData((prev) => ({ ...prev, city: value }));
    setCitySuggestions([]);
  };

  const removeImage = (index) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const submitCar = () => {
    const data = new FormData();

    for (let key in formData) {
      if (key === 'images') {
        formData.images.forEach((img) => data.append('images', img));
      } else if (key === 'video_360') {
        if (formData.video_360) {
          data.append('video_360', formData.video_360);
        }
      } else {
        if (key === 'price_per_day') {
          data.append(key, parseFloat(formData[key]));
        } else if (key === 'mileage') {
          data.append(key, parseInt(formData[key], 10));
        } else {
          data.append(key, formData[key]);
        }
      }
    }

    axios.post('https://innermentorlab.com/api/user/cars/', data, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data'
      }
    })
      .then((res) => {
        updateCars(prev => [...prev, res.data]);
        setView('list');
      })
      .catch((err) => {
        console.error("Error creating car:", err.response?.data || err);
        alert("Error creating car");
      });
  };

  return (
    <div className="create-form">
      <h2>Create a Car</h2>

      <input
        type="text"
        placeholder="Car name"
        value={searchTerm}
        onChange={handleBrandInput}
        autoComplete="off"
      />
      {showSuggestions && (
        <ul className="suggestions-list">
          {suggestions.map((s, i) => (
            <li key={i} onClick={() => selectSuggestion(s)}>{s}</li>
          ))}
        </ul>
      )}

      <textarea name="description_ru" placeholder="Description (RU)" onChange={handleChange} />
      <textarea name="description_en" placeholder="Description (EN)" onChange={handleChange} />
      <input name="price_per_day" placeholder="Price per day" onChange={handleChange} />
      <input name="mileage" placeholder="Mileage (km)" onChange={handleChange} />
      <textarea name="pricing_examples" placeholder="Pricing examples" onChange={handleChange} />

      <select name="category" onChange={handleChange}>
        <option value="">Category</option>
        <option value="No deposit">No deposit</option>
        <option value="Economy">Economy</option>
        <option value="Standard">Standard</option>
        <option value="Business">Business</option>
        <option value="Luxury">Luxury</option>
        <option value="Sport">Sport</option>
        <option value="Electric">Electric</option>
        <option value="7 seats">7 seats</option>
      </select>

      <label className="checkbox-row">
        <input type="checkbox" name="is_automatic" onChange={handleChange} />
        Automatic transmission
      </label>

      <input type="file" name="images" multiple onChange={handleChange} />
      {formData.images.length > 0 && (
        <ul className="file-list">
          {formData.images.map((file, i) => (
            <li key={i}>{file.name} <button onClick={() => removeImage(i)}>✖</button></li>
          ))}
        </ul>
      )}

      <input
        type="text"
        name="city"
        value={formData.city}
        placeholder="City"
        onChange={handleCityInput}
        autoComplete="off"
      />
      {citySuggestions.length > 0 && (
        <ul className="suggestions-list">
          {citySuggestions.map((s, i) => (
            <li key={i} onClick={() => selectCity(s)}>{s}</li>
          ))}
        </ul>
      )}

      <label>Year of manufacture: {formData.year}</label>
      <Slider
        value={formData.year}
        min={1900}
        max={2030}
        step={1}
        valueLabelDisplay="auto"
        onChange={(e, val) => setFormData(prev => ({ ...prev, year: val }))}
      />

      <label>Upload 360° video</label>
      <input type="file" name="video_360" accept="video/*" onChange={handleChange} />

      <button onClick={submitCar}>Create</button>
    </div>
  );
}
