import React from "react";
import {
  Container,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Grid,
  Box,
  Divider,
  List,
  ListItem,
  ListItemText,
} from "@mui/material";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import img1 from './images/1.jpg';
import img2 from './images/2.webp'; 
import img3 from './images/3.jpg';

export default function AboutOasisCar() {
  return (
    <Container maxWidth="lg" sx={{ py: 6 }}>
      <Typography variant="h3" gutterBottom fontWeight={700} textAlign="center">
        О компании RTG luxury car rental
      </Typography>
      <Typography variant="body1" paragraph textAlign="center">
        RTG luxury car rental — ваш надежный сервис по аренде автомобилей в Дубае! Мы делаем аренду автомобиля простой, быстрой и удобной — без лишних хлопот и с максимальным комфортом для клиентов,
       соединяющий клиентов с проверенными арендаторами. Более 2300+ автомобилей в базе. Мы работаем в Дубае, планируем расширение.

У нас нет скрытых комиссий. Всё прозрачно. Поддержка клиентов осуществляется через сайт.

Доступно для всех: туристов и резидентов. Аренда суперкаров — с 21 года и с действующими документами.
      </Typography>

      <Divider sx={{ my: 4 }} />

      <Accordion>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="h5" fontWeight={600}>Почему выбирают RTG luxury car rental?</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <List>
            <ListItem><ListItemText primary="Большой выбор автомобилей — от эконома до люкса." /></ListItem>
            <ListItem><ListItemText primary="Без депозита — арендуйте автомобиль без залогов." /></ListItem>
            <ListItem><ListItemText primary="Удобное бронирование — через сайт всего за пару минут." /></ListItem>
            <ListItem><ListItemText primary="Круглосуточная поддержка — служба поддержки 24/7." /></ListItem>
          </List>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="h5" fontWeight={600}>Наш автопарк</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant="body1" paragraph>
            <strong>Роскошные и спортивные автомобили:</strong> McLaren 720S, Rolls Royce, Porsche, Lamborghini, Ferrari и др.
          </Typography>
          <Typography variant="body1" paragraph>
            <strong>Эконом и бизнес-класс:</strong> Mercedes, Audi, BMW и другие по доступным ценам.
          </Typography>
          <Grid container spacing={2} mt={2} justifyContent="center">
            <Grid item xs={12} sm={6} md={3}>
              <Box component="img" src={img1} alt="Luxury Cars" width="100%" borderRadius={2} sx={{ maxHeight: 140, objectFit: 'cover' }} />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box component="img" src={img2} alt="Sport Cars" width="100%" borderRadius={2} sx={{ maxHeight: 140, objectFit: 'cover' }} />
            </Grid>
            <Grid item xs={12} sm={6} md={3}>
              <Box component="img" src={img3} alt="Economy Cars" width="100%" borderRadius={2} sx={{ maxHeight: 140, objectFit: 'cover' }} />
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="h5" fontWeight={600}>Процесс аренды</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <List>
            <ListItem><ListItemText primary="Выбор автомобиля на сайте" /></ListItem>
            <ListItem><ListItemText primary="Указание дат получения и возврата" /></ListItem>
            <ListItem><ListItemText primary="Онлайн-бронирование" /></ListItem>
            <ListItem><ListItemText primary="Получение подтверждения и документов" /></ListItem>
          </List>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="h5" fontWeight={600}>Необходимые документы</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Grid container spacing={4}>
            <Grid item xs={12} md={6}>
              <Typography variant="h6" fontWeight={500}>Для резидентов ОАЭ:</Typography>
              <List>
                <ListItem><ListItemText primary="Водительское удостоверение ОАЭ" /></ListItem>
                <ListItem><ListItemText primary="Эмиратская ID-карта или виза" /></ListItem>
              </List>
            </Grid>
            <Grid item xs={12} md={6}>
              <Typography variant="h6" fontWeight={500}>Для туристов:</Typography>
              <List>
                <ListItem><ListItemText primary="Паспорт" /></ListItem>
                <ListItem><ListItemText primary="Визитная виза" /></ListItem>
                <ListItem><ListItemText primary="Международное и местное водительское удостоверение" /></ListItem>
              </List>
            </Grid>
          </Grid>
        </AccordionDetails>
      </Accordion>

      <Accordion>
        <AccordionSummary expandIcon={<ExpandMoreIcon />}>
          <Typography variant="h5" fontWeight={600}>Дополнительная информация</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography variant="body1" paragraph>
            RTG luxury car rental — маркетплейс, соединяющий клиентов с проверенными арендаторами. Более 2300+ автомобилей в базе. Мы работаем в Дубае, планируем расширение.
          </Typography>
          <Typography variant="body1" paragraph>
            У нас нет скрытых комиссий. Всё прозрачно. Поддержка клиентов осуществляется через сайт.
          </Typography>
          <Typography variant="body1" paragraph>
            Доступно для всех: туристов и резидентов. Аренда суперкаров — с 21 года и с действующими документами.
          </Typography>
        </AccordionDetails>
      </Accordion>
    </Container>
  );
}
