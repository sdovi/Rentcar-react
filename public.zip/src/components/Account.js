// Account.js
import { useState, useEffect } from 'react';
import axios from 'axios';
import CreateCar from './CreateCar';
import EditCar from './EditCar';
import '../style.css';

export default function Account() {
  const [view, setView] = useState('create');
  const [cars, setCars] = useState([]);
  const [selectedCar, setSelectedCar] = useState(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [carToDelete, setCarToDelete] = useState(null);
  const [showToast, setShowToast] = useState('');
  const token = localStorage.getItem('token');

  useEffect(() => {
    if (view === 'list') {
      axios.get('https://innermentorlab.com/api/user/cars/', {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => setCars(res.data))
      .catch(err => {
        console.error("Ошибка загрузки машин:", err);
        if (err.response?.status === 401) {
          alert("Сессия устарела. Пожалуйста, войдите заново.");
          localStorage.removeItem('token');
          window.location.href = '/login';
        }
      });
    }
  }, [view, token]);

  const confirmDelete = (car) => {
    setCarToDelete(car);
    setShowConfirm(true);
  };

  const handleDelete = () => {
    if (!carToDelete) return;
    axios.delete(`https://innermentorlab.com/api/user/cars/${carToDelete.id}/`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    .then(() => {
      setCars(prev => prev.filter(c => c.id !== carToDelete.id));
      setShowConfirm(false);
      setCarToDelete(null);
      showTemporaryToast('Машина удалена успешно');
    })
    .catch(err => alert("Ошибка удаления"));
  };

  const startEdit = (car) => {
    setSelectedCar(car);
  };

  const showTemporaryToast = (msg) => {
    setShowToast(msg);
    setTimeout(() => setShowToast(''), 3000);
  };

  return (
    <div className="account-container">
      <div className="account-buttons">
        <button
          onClick={() => {
            setView('create');
            setSelectedCar(null);
          }}
          className={view === 'create' ? 'active' : ''}
        >Создать тачку</button>
        <button
          onClick={() => {
            setView('list');
            setSelectedCar(null);
          }}
          className={view === 'list' ? 'active' : ''}
        >Мои тачки</button>
      </div>

      {view === 'create' && !selectedCar && <CreateCar updateCars={setCars}  setView={setView} />}

      {view === 'list' && !selectedCar && (
        <div className="car-grid">
          {cars.map((car) => (
            <div key={car.id} className="car-card">
              <img
                src={car.images[0]?.image}
                alt={car.name_ru}
                className="car-image"
                onClick={() => startEdit(car)}
              />
              <div className="car-content">
                <h4>{car.name_ru}</h4>
                <p>{car.price_per_day} AED/день</p>
                <button className="delete-btn" onClick={() => confirmDelete(car)}>Удалить</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {selectedCar && (
        <div className="modal-overlay">
          <div className="modal large-modal">
            <EditCar
              car={selectedCar}
              onBack={() => {
                setSelectedCar(null);
                setView('list');
              }}
              onSaved={() => {
                setSelectedCar(null);
                setView('list');
                showTemporaryToast('Машина обновлена');
              }}
            />
          </div>
        </div>
      )}

      {showConfirm && (
        <div className="modal-overlay">
          <div className="modal">
            <p>Вы уверены, что хотите удалить <b>{carToDelete?.name_ru}</b>?</p>
            <button className="confirm-btn" onClick={handleDelete}>Удалить</button>
            <button className="cancel-btn" onClick={() => setShowConfirm(false)}>Отмена</button>
          </div>
        </div>
      )}

      {showToast && (
        <div className="toast">{showToast}</div>
      )}
    </div>
  );
}