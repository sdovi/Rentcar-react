// src/components/Register.jsx
import React, { useState } from 'react';
import axios from 'axios';
import '../style.css';
import { useNavigate } from 'react-router-dom';

export default function Register({ lang }) {
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    email: '',
    password: ''
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Переводы
  const translations = {
    en: {
      title: 'Register',
      firstName: 'First Name',
      lastName: 'Last Name',
      email: 'Email',
      password: 'Password',
      submit: 'Sign Up',
      error: 'Registration failed'
    },
    ru: {
      title: 'Регистрация',
      firstName: 'Имя',
      lastName: 'Фамилия',
      email: 'Email',
      password: 'Пароль',
      submit: 'Зарегистрироваться',
      error: 'Ошибка регистрации'
    },
    de: {
      title: 'Registrieren',
      firstName: 'Vorname',
      lastName: 'Nachname',
      email: 'E-Mail',
      password: 'Passwort',
      submit: 'Anmelden',
      error: 'Registrierung fehlgeschlagen'
    },
    es: {
      title: 'Registro',
      firstName: 'Nombre',
      lastName: 'Apellido',
      email: 'Correo electrónico',
      password: 'Contraseña',
      submit: 'Registrarse',
      error: 'Error al registrarse'
    },
    ar: {
      title: 'التسجيل',
      firstName: 'الاسم الأول',
      lastName: 'اسم العائلة',
      email: 'البريد الإلكتروني',
      password: 'كلمة المرور',
      submit: 'سجل',
      error: 'فشل التسجيل'
    },
  };

  const t = translations[lang] || translations.en;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    axios.post('https://innermentorlab.com/api/register/', form)
      .then(() => {
        navigate('/login');
      })
      .catch(() => {
        setError(t.error);
        setTimeout(() => setError(''), 3000);
      });
  };

  return (
    <div className="auth-form">
      <h2>{t.title}</h2>

      <input
        name="first_name"
        placeholder={t.firstName}
        onChange={handleChange}
        value={form.first_name}
      />
      <input
        name="last_name"
        placeholder={t.lastName}
        onChange={handleChange}
        value={form.last_name}
      />
      <input
        name="email"
        placeholder={t.email}
        onChange={handleChange}
        value={form.email}
      />
      <input
        name="password"
        type="password"
        placeholder={t.password}
        onChange={handleChange}
        value={form.password}
      />

      <button onClick={handleSubmit}>{t.submit}</button>
      {error && <div className="toast">{error}</div>}

      <div className="have-account">
  Already have an account? <a href="/login">/login</a>
</div>

    </div>
  );
}
