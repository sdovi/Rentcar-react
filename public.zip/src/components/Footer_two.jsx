import React from "react";
import { useNavigate } from "react-router-dom";
import { GoHome } from "react-icons/go";
import { FiSearch, FiMenu } from "react-icons/fi";
import { FaPlus } from "react-icons/fa";
import { AiOutlineHeart } from "react-icons/ai";
import { Badge } from "@mui/material";
import { useCart } from "../context/CartContext"; // если не импортировал ещё

const Footer2 = () => {
  const { cartItems } = useCart();
  const navigate = useNavigate();

  const handleSearchFocus = () => {
    const input = document.querySelector(".search-input");
    if (input) {
      window.dispatchEvent(new Event("focusSearchInput"));
    } else {
      navigate("/");
      setTimeout(() => {
        window.dispatchEvent(new Event("focusSearchInput"));
      }, 300);
    }
  };
  const handleMenuClick = () => {
    window.dispatchEvent(new Event("openNavbarMenu"));
  };

  const handlePostAdClick = () => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/account");
    } else {
      navigate("/register");
    }
  };
  return (
    <footer className="footer-container">
      <button className="footer-item" onClick={() => navigate("/")}>
        <GoHome className="icon" />
        <span>Home</span>
      </button>

      <button className="footer-item" onClick={handleSearchFocus}>
        <FiSearch className="icon" />
        <span>Search</span>
      </button>

      <button
        className="footer-item post-ad-button"
        onClick={handlePostAdClick}
      >
        <div className="icon-wrapper">
          <FaPlus className="icon" />
        </div>
        <span>Post an ad</span>
      </button>

     <button className="footer-item" onClick={() => navigate("/cart")}>
      <Badge
        badgeContent={cartItems.length}
        color="error"
        sx={{
          ".MuiBadge-badge": {
            top: 2,
            right: 2,
            fontSize: "0.7rem",
          },
        }}
      >
        <AiOutlineHeart className="icon" />
      </Badge>
      <span>Likes</span>
    </button>
      <button className="footer-item" onClick={handleMenuClick}>
        <FiMenu className="icon" />
        <span>Menu</span>
      </button>
    </footer>
  );
};

export default Footer2;
