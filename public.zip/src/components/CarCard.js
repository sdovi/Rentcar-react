import React, { useState, useRef, useEffect } from "react";
import "../style.css";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import StarIcon from "@mui/icons-material/Star";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import EventSeatIcon from "@mui/icons-material/EventSeat";
import DoorFrontIcon from "@mui/icons-material/DoorFront";
import LuggageIcon from "@mui/icons-material/Luggage";
import PhoneIcon from "@mui/icons-material/Phone";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import ShareIcon from "@mui/icons-material/Share";

export default function CarCard({ car, lang }) {
  const navigate = useNavigate();
  const { addToCart, removeFromCart, isInCart } = useCart();
  const inCart = isInCart(car.id);

  const name = lang === "ru" ? car.name_ru : car.name_en;
  const descFull = lang === "ru" ? car.description_ru : car.description_en;
  const descSnippet = descFull
    ? descFull.length > 15
      ? descFull.substring(0, 15) + "..."
      : descFull
    : "";

  const images =
    Array.isArray(car.images) && car.images.length > 0
      ? car.images.map((i) => i.image)
      : ["https://via.placeholder.com/400x250?text=No+Image"];

  const [index, setIndex] = useState(0);
  const discount = 20;

  const nextImage = (e) => {
    e.stopPropagation();
    setIndex((i) => (i + 1) % images.length);
  };

  const prevImage = (e) => {
    e.stopPropagation();
    setIndex((i) => (i - 1 + images.length) % images.length);
  };

  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold: 0.2 }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const handleShare = async (e) => {
    e.stopPropagation();
    const shareData = {
      title: name,
      text: `Оцени этот автомобиль: ${name}`,
      url: `${window.location.origin}/car/${car.id}`,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error("Ошибка при попытке поделиться:", err);
      }
    } else {
      alert("На вашем устройстве эта функция не поддерживается.");
    }
  };

  return (
    <div
      ref={ref}
      className={`car-card-new${visible ? " visible" : ""}`}
      onClick={() => navigate(`/car/${car.id}`)}
      style={{ cursor: "pointer" }}
    >
      <div className="car-image-wrapper" style={{ position: "relative" }}>
        <img src={images[index]} alt={name} className="car-image-new" />

        {images.length > 1 && (
          <>
            <button className="slider-btn left" onClick={prevImage}>
              <ArrowBackIosIcon fontSize="small" style={{ color: "black" }} />
            </button>
            <button className="slider-btn right" onClick={nextImage}>
              <ArrowForwardIosIcon fontSize="small" style={{ color: "black" }} />
            </button>
          </>
        )}

        <div
          className="top-right-icons"
          style={{
            position: "absolute",
            top: 8,
            right: 8,
            display: "flex",
            gap: "8px",
          }}
        >
          <div
            className="share-btn"
            onClick={handleShare}
            style={{
              background: "rgba(0,0,0,0.4)",
              borderRadius: "50%",
              padding: "4px",
              cursor: "pointer",
              color: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <ShareIcon fontSize="medium" />
          </div>

          <div
            className="favorite-btn"
            onClick={(e) => {
              e.stopPropagation();
              inCart ? removeFromCart(car.id) : addToCart(car);
            }}
            style={{
              background: "rgba(0,0,0,0.4)",
              borderRadius: "50%",
              padding: "4px",
              cursor: "pointer",
              color: inCart ? "red" : "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {inCart ? <FavoriteIcon /> : <FavoriteBorderIcon />}
          </div>
        </div>

        <div className="discount-label">-{discount}%</div>
        <div className="dot-indicator">
          {images.map((_, i) => (
            <span key={i} className={i === index ? "active" : ""}></span>
          ))}
        </div>
      </div>

      <div className="car-info">
        <h3 className="car-name">{name}</h3>
        <p className="car-desc">{descSnippet}</p>

        <div className="car-specs">
          <div className="spec-item">
            <CalendarTodayIcon fontSize="small" /> {car.year}
          </div>
          <div className="spec-item">
            <EventSeatIcon fontSize="small" /> {car.seats || 5}
          </div>
          <div className="spec-item">
            <DoorFrontIcon fontSize="small" /> {car.doors || 4}
          </div>
          <div className="spec-item">
            <LuggageIcon fontSize="small" /> {car.luggage || 3}
          </div>
        </div>

        <div className="car-rating">
          <StarIcon style={{ color: "green", fontSize: 18 }} />{" "}
          {car.rating || 9.5} ({car.reviews || "300+"}) · Premium Company
        </div>

        <div className="car-price-section">
          <div className="price-old">{car.price_per_day + 100} AED/д.</div>
          <div className="price-current">{car.price_per_day} AED/д.</div>
          <div className="price-total">Всего: {car.price_per_day * 3} AED</div>
        </div>

        <div
          className="car-action-buttons"
          style={{
            display: "flex",
            width: "100%",
            gap: "10px",
          }}
        >
          <button
            onClick={(e) => {
              e.stopPropagation();
              window.location.href = "tel:+971000000000";
            }}
            style={{
              flex: 1,
              backgroundColor: "black",
              color: "white",
              border: "2px solid red",
              borderRadius: "0 0 0 12px",
              padding: "12px 0",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "6px",
              cursor: "pointer",
            }}
          >
            <PhoneIcon fontSize="small" />
            Call
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              window.open("https://wa.me/971000000000", "_blank");
            }}
            style={{
              flex: 1,
              backgroundColor: "green",
              color: "white",
              border: "none",
              borderRadius: "0 0 12px 0",
              padding: "12px 0",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "6px",
              cursor: "pointer",
            }}
          >
            <WhatsAppIcon fontSize="small" />
            WhatsApp
          </button>
        </div>
      </div>
    </div>
  );
}