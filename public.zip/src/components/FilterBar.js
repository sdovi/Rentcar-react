import React from "react";
import "../style.css";
import {
  FaCar,
  FaBolt,
  FaCouch,
  FaMoneyBillAlt,
  FaStar,
  FaGem,
  FaFutbol,
  FaUsers,
  FaGift,
} from "react-icons/fa";

// Оригинальные категории (ключи для фильтрации)
const categories = [
  { key: "Все", icon: <FaCar /> },
  { key: "Без депозита", icon: <FaGift /> },
  { key: "Эконом", icon: <FaMoneyBillAlt /> },
  { key: "Стандарт", icon: <FaCouch /> },
  { key: "Бизнес", icon: <FaStar /> },
  { key: "Люкс", icon: <FaGem /> },
  { key: "Спорт", icon: <FaFutbol /> },
  { key: "Электро", icon: <FaBolt /> },
  { key: "7 мест", icon: <FaUsers /> },
];

// Переводы для отображения
const translations = {
  en: {
    categories: [
      "All",
      "No deposit",
      "Economy",
      "Standard",
      "Business",
      "Luxury",
      "Sport",
      "Electric",
      "7 seats",
    ],
    sort: { asc: "Cheapest", desc: "Most expensive" },
  },
  ru: {
    categories: [
      "Все",
      "Без депозита",
      "Эконом",
      "Стандарт",
      "Бизнес",
      "Люкс",
      "Спорт",
      "Электро",
      "7 мест",
    ],
    sort: { asc: "Самые дешёвые", desc: "Самые дорогие" },
  },
  de: {
    categories: [
      "Alle",
      "Ohne Anzahlung",
      "Economy",
      "Standard",
      "Business",
      "Luxus",
      "Sport",
      "Elektrisch",
      "7 Sitze",
    ],
    sort: { asc: "Günstigste", desc: "Teuerste" },
  },
  es: {
    categories: [
      "Todos",
      "Sin depósito",
      "Económico",
      "Estándar",
      "Negocio",
      "Lujo",
      "Deportivo",
      "Eléctrico",
      "7 plazas",
    ],
    sort: { asc: "Más barato", desc: "Más caro" },
  },
  ar: {
    categories: [
      "الكل",
      "بدون تأمين",
      "اقتصادي",
      "عادي",
      "أعمال",
      "فاخر",
      "رياضي",
      "كهربائي",
      "7 مقاعد",
    ],
    sort: { asc: "الأرخص", desc: "الأغلى" },
  },
};

export default function FilterBar({ active, setActive, sort, setSort, lang }) {
  const t = translations[lang] || translations.en;

  const toggleCategory = (key) => {
    // логика как в вашем рабочем коде
    setActive(key === "Все" ? "" : key);
  };

  const toggleSort = (type) => {
    setSort((prev) => (prev === type ? "" : type));
  };

  return (
    <div>
      <div className="filter-bar-wrapper">
        <div className="filter-bar">
          {categories.map((cat, idx) => {
            // определяем, активна ли кнопка
            const isActive =
              active === cat.key || (cat.key === "Все" && !active);
            return (
              <button
                key={cat.key}
                onClick={() => toggleCategory(cat.key)}
                className={`filter-button ${isActive ? "active" : ""}`}
              >
                <span className="icon">{cat.icon}</span>{" "}
                {t.categories[idx] /* отображаем переведённый label */}
              </button>
            );
          })}
        </div>
      </div>

      <div className="sort-bar">
        <button
          onClick={() => toggleSort("asc")}
          className={`sort-button ${sort === "asc" ? "active" : ""}`}
        >
          {t.sort.asc}
        </button>
        <button
          onClick={() => toggleSort("desc")}
          className={`sort-button ${sort === "desc" ? "active" : ""}`}
        >
          {t.sort.desc}
        </button>
      </div>
    </div>
  );
}
