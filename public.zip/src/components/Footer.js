import { Box, Typography, IconButton, Container } from "@mui/material";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import TelegramIcon from "@mui/icons-material/Telegram";
import oasisLogo from "./oasis.png";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";
import { SiTiktok, SiSnapchat } from "react-icons/si";
const ICON_SIZE = 24; // пиксели
export default function Footer() {
  const commonSx = {
    color: "white",
    "& svg": { fontSize: ICON_SIZE }, // для всех SVG внутри
    "&:hover": { color: "grey.400" },
  };

  return (
    <div className="Footer">
      <Box
        component="footer"
        sx={{
          backgroundColor: "#f5f5f5",
          borderTop: "1px solid #ff3d00",
          py: 3,
          mt: 5,
        }}
      >
        <Container
          maxWidth="md"
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
          }}
        >
          <Typography
            variant="body1"
            fontWeight="bold"
            sx={{ mb: { xs: 1, md: 0 } }}
          >
            RTG luxury car rentals © {new Date().getFullYear()}
          </Typography>

          <Box
            component="img"
            src={oasisLogo}
            alt="Oasis"
            sx={{
              height: ICON_SIZE,
              width: ICON_SIZE,
            }}
          />

          <Box sx={{ bgcolor: "black", p: 1, display: "flex", gap: 1 }}>
            <IconButton
              component="a"
              href="https://wa.me/971508280101"
              target="_blank"
              rel="noopener"
              aria-label="WhatsApp"
              sx={commonSx}
            >
              <WhatsAppIcon />
            </IconButton>

            <IconButton
              component="a"
              href="https://t.me/rtg_luxurycars"
              target="_blank"
              rel="noopener"
              aria-label="Telegram"
              sx={commonSx}
            >
              <TelegramIcon />
            </IconButton>

            <IconButton
              component="a"
              href="tel:+971508280101"
              aria-label="Phone"
              sx={commonSx}
            >
              <PhoneIcon />
            </IconButton>

            <IconButton
              component="a"
              href="mailto:info@rtgluxurycars.com"
              aria-label="Email"
              sx={commonSx}
            >
              <EmailIcon />
            </IconButton>

            <IconButton
              component="a"
              href="https://www.tiktok.com/@rtg.luxurycars"
              target="_blank"
              rel="noopener"
              aria-label="TikTok"
              sx={commonSx}
            >
              <SiTiktok size={ICON_SIZE} />
            </IconButton>

            <IconButton
              component="a"
              href="https://snapchat.com/add/rtg.luxurycars"
              target="_blank"
              rel="noopener"
              aria-label="Snapchat"
              sx={commonSx}
            >
              <SiSnapchat size={ICON_SIZE} />
            </IconButton>
          </Box>
        </Container>
      </Box>
    </div>
  );
}
