// src/context/CartContext.jsx
import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

export function CartProvider({ children }) {
  // 1) Инициализируем из localStorage
  const [cartItems, setCartItems] = useState(() => {
    try {
      const stored = localStorage.getItem('cart');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // 2) При каждом изменении cartItems — синхронизируем его c localStorage
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = car => {
    setCartItems(prev => {
      if (prev.find(item => item.id === car.id)) return prev;
      return [...prev, car];
    });
  };

  const removeFromCart = carId => {
    setCartItems(prev => prev.filter(item => item.id !== carId));
  };

  const isInCart = carId => cartItems.some(item => item.id === carId);

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, isInCart }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used inside CartProvider");
  return ctx;
}
