export const mockCars = [
  {
    id: 1,
    name_ru: "Hyundai Tucson 2020",
    name_en: "Hyundai Tucson 2020",
    description_ru: "Городской кроссовер с хорошим клиренсом и современным дизайном.",
    description_en: "Urban crossover with good ground clearance and modern design.",
    price_per_day: 120,
    mileage: 600,
    pricing_examples: "360 AED / 3 дня",
    category: "Бизнес",
    is_automatic: true,
    images: [
      { image: "https://images.pexels.com/photos/10074110/pexels-photo-10074110.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" },
      { image: "https://images.pexels.com/photos/358070/pexels-photo-358070.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" }
    ]
  },
  {
    id: 2,
    name_ru: "Nissan Sunny 2022",
    name_en: "Nissan Sunny 2022",
    description_ru: "Надежный экономичный седан, идеальный для города.",
    description_en: "Reliable fuel-efficient sedan, perfect for city use.",
    price_per_day: 85,
    mileage: 750,
    pricing_examples: "255 AED / 3 дня",
    category: "Эконом",
    is_automatic: true,
    images: [
      { image: "https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" }
    ]
  },
  {
    id: 3,
    name_ru: "BMW X5 2023",
    name_en: "BMW X5 2023",
    description_ru: "Премиум-внедорожник с мощным двигателем и роскошным салоном.",
    description_en: "Premium SUV with powerful engine and luxury interior.",
    price_per_day: 270,
    mileage: 500,
    pricing_examples: "810 AED / 3 дня",
    category: "Люкс",
    is_automatic: true,
    images: [
      { image: "https://images.pexels.com/photos/358070/pexels-photo-358070.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" },
      { image: "https://images.pexels.com/photos/24353/pexels-photo.jpg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" }
    ]
  }
];
