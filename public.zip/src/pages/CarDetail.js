import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";
import {
  Container,
  Typography,
  Box,
  Button,
  IconButton,
  Modal,
  TextField,
  Fade,
  Grid,
  Paper,
} from "@mui/material";
import CheckIcon from "@mui/icons-material/Check";
import WhatsAppIcon from "@mui/icons-material/WhatsApp";
import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import PhoneIcon from "@mui/icons-material/Phone";
import { useSwipeable } from "react-swipeable";

import { Stack, Divider } from "@mui/material";
import React from "react";
// --- CALENDAR IMPORTS ---
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
// No need to import 'ru' locale for English

// --- BUTTON IMPORTS ---
import { useCart } from "../context/CartContext";
import ShareIcon from "@mui/icons-material/Share";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";

import "../style.css";

const modalStyle = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "#121212",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  borderRadius: 2,
  color: "white",
};

export default function CarDetail({ lang }) {
  const { id } = useParams();
  const [car, setCar] = useState(null);
  const [index, setIndex] = useState(0);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState([null, null]);
  const [userName, setUserName] = useState("");
  const [userPhone, setUserPhone] = useState("");

  const rentalTerms = [
    { label: "Full Insurance", value: "Additional Charges" },
    { label: "Delivery & Pickup", value: "Not Available" },
    { label: "Security Deposit", value: "AED 1500" },
    { label: "Refunded in", value: "21 days" },
    { label: "Minimum Driver's Age", value: "21 years" },
  ];
  // Предположим, что у нас есть состояние для отслеживания активной вкладки
  const [activeTab, setActiveTab] = React.useState("tourists"); // 'tourists' is now the active tab

  useEffect(() => {
    axios
      .get(`https://innermentorlab.com/api/cars/${id}/`)
      .then((res) => {
        setCar(res.data);
        setIndex(0);
      })
      .catch((err) => {
        console.error("Car not found:", err);
        setCar(null);
      });
  }, [id]);

  const handleOpenModal = () => setIsModalOpen(true);
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setDateRange([null, null]);
    setUserName("");
    setUserPhone("");
  };

  const handleBookingSubmit = () => {
    if (!userName || !userPhone) {
      alert("Please enter your name and phone number.");
      return;
    }
    if (!dateRange[0] || !dateRange[1]) {
      alert("Please select a start and end date for the rental.");
      return;
    }

    const bookingDetails = {
      carId: car.id,
      carName: lang === "ru" ? car.name_ru : car.name_en,
      startDate: dateRange[0],
      endDate: dateRange[1],
      customerName: userName,
      customerPhone: userPhone,
    };

    console.log("BOOKING DETAILS:", bookingDetails);

    alert(
      `Your booking request for the ${bookingDetails.carName} has been received! We will contact you at ${bookingDetails.customerPhone}.`
    );

    const TELEGRAM_BOT_TOKEN = "7318091039:AAGojOrjI0nEdYlJ3CDgHpB9Sv9j3R8jnVQ";
    const TELEGRAM_CHAT_ID = "-4989521046";

    const message = `
        🚗 <b>New Booking</b>
        <b>Car:</b> ${bookingDetails.carName}
        <b>From:</b> ${bookingDetails.startDate.toLocaleDateString()}
        <b>To:</b> ${bookingDetails.endDate.toLocaleDateString()}
        <b>Name:</b> ${bookingDetails.customerName}
        <b>Phone:</b> ${bookingDetails.customerPhone}
  `.trim();

    axios
      .post(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
        {
          chat_id: TELEGRAM_CHAT_ID,
          text: message,
          parse_mode: "HTML",
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      )
      .then(() => {
        console.log("Message sent successfully to Telegram");
      })
      .catch((err) => {
        console.error(
          "Error sending to Telegram:",
          err.response?.data || err.message
        );
      });

    handleCloseModal();
  };

  const nextImage = () => {
    if (car?.images?.length > 0) {
      setIndex((prev) => (prev + 1) % car.images.length);
    }
  };

  const prevImage = () => {
    if (car?.images?.length > 0) {
      setIndex((prev) => (prev - 1 + car.images.length) % car.images.length);
    }
  };

  const handlers = useSwipeable({
    onSwipedLeft: nextImage,
    onSwipedRight: prevImage,
    preventScrollOnSwipe: true,
    trackMouse: true,
  });

  const { addToCart, removeFromCart, isInCart } = useCart();
  const inCart = car ? isInCart(car.id) : false;

  const handleShare = async (e) => {
    e.stopPropagation();
    const carName = lang === "ru" ? car.name_ru : car.name_en;
    const shareData = {
      title: carName,
      text: `Check out this car: ${carName}`,
      url: `${window.location.origin}/car/${car.id}`,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error("Error while trying to share:", err);
      }
    } else {
      alert("This feature is not supported on your device.");
    }
  };

  if (!car) {
    return <p className="loading-text">Car not found</p>;
  }

  const name = lang === "ru" ? car.name_ru : car.name_en;
  const price_per_day = car.price_per_day;
  const price_per_month = Number(car.price_per_day) * 30;
  const price_per_week = Number(car.price_per_day) * 7;
  const desc = lang === "ru" ? car.description_ru : car.description_en;
  const images = car.images || [];
  const whatsapp = "971508280101";

  return (
    <Container maxWidth="md" sx={{ pt: 3, pb: 8 }}>
      <Link
        to="/"
        className="back-link"
        style={{ marginBottom: 16, display: "inline-block" }}
      >
        ← Back
      </Link>

      {images.length > 0 ? (
        <Box
          position="relative"
          {...handlers}
          sx={{ borderRadius: 3, overflow: "hidden" }}
        >
          <Box
            sx={{
              position: "relative",
              height: 300,
              overflow: "hidden",
              borderRadius: 3,
              mb: 1,
            }}
          >
            {images.map((img, i) => (
              <Box
                key={i}
                component="img"
                src={img.image}
                alt={`${name} image ${i + 1}`}
                sx={{
                  position: "absolute",
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  top: 0,
                  left: 0,
                  opacity: i === index ? 1 : 0,
                  transition: "opacity 0.5s ease-in-out",
                }}
              />
            ))}
          </Box>

          <Box sx={{ position: "absolute", bottom: 0, right: 0, zIndex: 10 }}>
            <div style={{ display: "flex", gap: "8px", padding: "10px" }}>
              <div
                className="share-btn"
                onClick={handleShare}
                style={{
                  background: "rgba(0, 0, 0, 0.4)",
                  borderRadius: "50%",
                  padding: "4px",
                  cursor: "pointer",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <ShareIcon fontSize="medium" />
              </div>
              <div
                className="favorite-btn"
                onClick={(e) => {
                  e.stopPropagation();
                  inCart ? removeFromCart(car.id) : addToCart(car);
                }}
                style={{
                  background: "rgba(0,0,0,0.4)",
                  borderRadius: "50%",
                  padding: "4px",
                  cursor: "pointer",
                  color: inCart ? "red" : "#fff",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                {inCart ? <FavoriteIcon /> : <FavoriteBorderIcon />}
              </div>
            </div>
          </Box>

          {images.length > 1 && (
            <>
              <IconButton
                onClick={prevImage}
                sx={{
                  position: "absolute",
                  top: "50%",
                  left: 8,
                  transform: "translateY(-50%)",
                  background: "rgba(255, 255, 255, 0.7)",
                }}
              >
                <ArrowBackIosNewIcon fontSize="small" />
              </IconButton>
              <IconButton
                onClick={nextImage}
                sx={{
                  position: "absolute",
                  top: "50%",
                  right: 8,
                  transform: "translateY(-50%)",
                  background: "rgba(255, 255, 255, 0.7)",
                }}
              >
                <ArrowForwardIosIcon fontSize="small" />
              </IconButton>
            </>
          )}
        </Box>
      ) : (
        <Box
          sx={{
            height: 300,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            border: "1px dashed grey",
            borderRadius: 3,
            mb: 1,
          }}
        >
          <Typography>No images available</Typography>
        </Box>
      )}

      <Box mt={2}>
        <Typography variant="h4" fontWeight="bold">
          {name}
        </Typography>

        <Box mt={0}>
          <Box sx={{ bgcolor: "#222", p: 2, borderRadius: 2, mb: 0 }}>
            <Typography variant="overline" color="grey.400">
              DAILY RENTAL
            </Typography>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-end",
              }}
            >
              <Typography variant="h5" fontWeight="bold">
                {price_per_day} <span style={{ fontSize: "1rem" }}>AED</span>
              </Typography>
              <Box textAlign="right">
                <Typography variant="body2">{car.mileage} km/day</Typography>
                <Typography variant="caption" color="grey.400">
                  0.5 AED per additional km
                </Typography>
              </Box>
            </Box>
          </Box>
          <Box
            className="rental-prices"
            sx={{ bgcolor: "#222", p: 2, borderRadius: 2, mb: 0 }}
          >
            <Typography variant="overline" color="grey.400">
              WEEKLY RENTAL
            </Typography>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-end",
              }}
            >
              <Typography variant="h5" fontWeight="bold">
                {price_per_week} <span style={{ fontSize: "1rem" }}>AED</span>
              </Typography>
              <Box textAlign="right">
                <Typography variant="body2">
                  {Number(car.mileage) * 7} km/week
                </Typography>
                <Typography variant="caption" color="grey.400">
                  0.5 AED per additional km
                </Typography>
              </Box>
            </Box>
          </Box>

          <Box sx={{ bgcolor: "#222", p: 2, borderRadius: 2 }}>
            <Typography variant="overline" color="grey.400">
              MONTHLY RENTAL
            </Typography>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-end",
              }}
            >
              <Typography variant="h5" fontWeight="bold">
                {price_per_month} <span style={{ fontSize: "1rem" }}>AED</span>
              </Typography>
              <Box textAlign="right">
                <Typography variant="body2">
                  {Number(car.mileage) * 30} km/month
                </Typography>
                <Typography variant="caption" color="grey.400">
                  0.5 AED per additional km
                </Typography>
              </Box>
            </Box>
          </Box>
        </Box>
        <Typography
          variant="body2"
          sx={{ mt: 2, whiteSpace: "pre-line", color: "white" }}
        >
          {desc}
        </Typography>

        <Grid container spacing={2} mt={2}>
          <Grid item xs={6}>
            <Typography variant="body2">
              <b>Price:</b> {car.price_per_day} AED/day
            </Typography>
            <Typography variant="body2">
              <b>Mileage:</b> {car.mileage} km
            </Typography>
            <Typography variant="body2">
              <b>Pricing examples:</b> {car.pricing_examples}
            </Typography>
          </Grid>
          <Grid item xs={6}>
            <Typography variant="body2">
              <b>Category:</b> {car.category}
            </Typography>
            <Typography variant="body2">
              <b>Transmission:</b> {car.is_automatic ? "Automatic" : "Manual"}
            </Typography>
          </Grid>
        </Grid>
        <Typography
          variant="subtitle1"
          color="white"
          gutterBottom
          sx={{ mt: 3 }}
        >
          {car.is_automatic ? "Automatic" : "Manual"} · {car.category}
        </Typography>
      </Box>

      <Box
        sx={{
          p: 1,
          backgroundColor: "#000",
          color: "#fff",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Box sx={{ width: "100%", maxWidth: 360 }}>
          <Typography variant="h6" gutterBottom textAlign="start">
            Rental Terms
          </Typography>
          <Stack spacing={2} divider={<Divider sx={{ borderColor: "#333" }} />}>
            {rentalTerms.map((item, index) => (
              <Box key={index} display="flex" justifyContent="space-between">
                <Typography variant="body2" color="white">
                  {item.label}
                </Typography>
                <Typography variant="body2" color="white" fontWeight="bold">
                  {item.value}
                </Typography>
              </Box>
            ))}
          </Stack>
        </Box>
      </Box>

      <Box
        sx={{
          width: "100%",
          margin: "auto", // Центрируем компонент
          padding: 3, // Добавляем внутренние отступы
          fontFamily: "sans-serif", // Устанавливаем базовый шрифт
          color: "#fff", // Основной цвет текста - белый
          bgcolor: "#000", // Предполагаемый черный фон
          borderRadius: 2, // Добавим скругление углов для эстетики
        }}
      >
        <Typography
          variant="h5"
          component="h2"
          sx={{ fontWeight: "bold", mb: 2, color: "#fff" }}
        >
          Documents Required
        </Typography>

        <Typography variant="body1" sx={{ mb: 4, color: "#eee" }}>
          You are eligible to rent a car across the emirates provided you have
          the below mentioned documents valid with you:
        </Typography>

        {/* Контейнер для вкладок */}
        <Box
          sx={{ borderBottom: 1, borderColor: "#444", mb: 3, display: "flex" }}
        >
          {/* Вкладка 1: UAE Residents */}
          <Typography
            variant="subtitle1"
            onClick={() => setActiveTab("residents")}
            sx={{
              fontWeight: "bold",
              pb: 1,
              px: 2, // Добавим горизонтальные отступы для разделения
              cursor: "pointer",
              position: "relative",
              color: activeTab === "residents" ? "red" : "#aaa", // Условный цвет текста
              "&::after": {
                // Псевдо-элемент для красной линии
                content: '""',
                display: activeTab === "residents" ? "block" : "none", // Показываем линию только для активной вкладки
                position: "absolute",
                bottom: "-1px",
                left: 0,
                width: "100%",
                height: "2px",
                backgroundColor: "red",
              },
            }}
          >
            UAE Residents
          </Typography>

          {/* Вкладка 2: Tourists visiting the UAE */}
          <Typography
            variant="subtitle1"
            onClick={() => setActiveTab("tourists")}
            sx={{
              fontWeight: "bold",
              pb: 1,
              px: 2,
              cursor: "pointer",
              position: "relative",
              color: activeTab === "tourists" ? "red" : "#aaa", // Условный цвет текста
              "&::after": {
                // Псевдо-элемент для красной линии
                content: '""',
                display: activeTab === "tourists" ? "block" : "none", // Показываем линию только для активной вкладки
                position: "absolute",
                bottom: "-1px",
                left: 0,
                width: "100%",
                height: "2px",
                backgroundColor: "red",
              },
            }}
          >
            Tourists visiting the UAE
          </Typography>
        </Box>

        {/* Условное отображение списка документов */}
        {activeTab === "residents" && (
          <Box>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <CheckIcon sx={{ color: "green", mr: 1.5 }} />
              <Typography variant="body1" sx={{ color: "#fff" }}>
                UAE Driving License
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "flex-start" }}>
              <CheckIcon sx={{ color: "green", mr: 1.5, mt: 0.5 }} />
              <Box>
                <Typography variant="body1" sx={{ color: "#fff" }}>
                  Emirates ID
                </Typography>
                <Typography variant="body2" sx={{ color: "#aaa" }}>
                  (Residential Visa may be acceptable)
                </Typography>
              </Box>
            </Box>
          </Box>
        )}

        {activeTab === "tourists" && (
          <Box>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <CheckIcon sx={{ color: "green", mr: 1.5 }} />
              <Typography variant="body1" sx={{ color: "#fff" }}>
                Passport
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <CheckIcon sx={{ color: "green", mr: 1.5 }} />
              <Typography variant="body1" sx={{ color: "#fff" }}>
                Visit Visa
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <CheckIcon sx={{ color: "green", mr: 1.5 }} />
              <Typography variant="body1" sx={{ color: "#fff" }}>
                Home Country Driving License
              </Typography>
            </Box>
            <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
              <CheckIcon sx={{ color: "green", mr: 1.5 }} />
              <Typography variant="body1" sx={{ color: "#fff" }}>
                International Driving Permit (IDP)
              </Typography>
            </Box>
          </Box>
        )}

        {/* Дополнительная информация для посетителей */}
        <Typography variant="body1" sx={{ mt: 4, color: "#eee" }}>
          Visitors from the GCC, US, UK, Canada, Europe and certain other
          countries can drive with their home country driving license, without
          the need of an IDP.
        </Typography>
      </Box>

      <Box sx={{ display: "flex", gap: 1, mt: 4 }}>
        <Button
          onClick={handleOpenModal}
          variant="contained"
          size="large"
          sx={{
            flex: 2,
            py: 1.5,
            fontWeight: "bold",
            backgroundColor: "#ff3d00",
            "&:hover": {
              backgroundColor: "#e63600",
            },
          }}
        >
          Book Now
        </Button>

        <Button
          onClick={(e) => {
            e.stopPropagation();
            window.location.href = `tel:+${whatsapp}`;
          }}
          variant="contained"
          sx={{
            flex: 1,
            backgroundColor: "black",
            color: "white",
            border: "2px solid #ff3d00",
            "&:hover": {
              backgroundColor: "#212121",
            },
          }}
        >
          <PhoneIcon />
        </Button>

        <Button
          onClick={(e) => {
            e.stopPropagation();
            window.open(`https://wa.me/${whatsapp}`, "_blank");
          }}
          variant="contained"
          sx={{
            flex: 1,
            backgroundColor: "#25D366",
            color: "white",
            "&:hover": {
              backgroundColor: "#1DAA50",
            },
          }}
        >
          <WhatsAppIcon />
        </Button>
      </Box>

      <Modal
        open={isModalOpen}
        onClose={handleCloseModal}
        aria-labelledby="booking-modal-title"
        closeAfterTransition
      >
        <Fade in={isModalOpen}>
          <Box sx={modalStyle}>
            <Typography
              id="booking-modal-title"
              variant="h6"
              component="h2"
              align="center"
              gutterBottom
              sx={{ color: "white" }}
            >
              Select Rental Dates
            </Typography>

            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DatePicker
                label="Start Date"
                value={dateRange[0]}
                onChange={(newValue) => setDateRange([newValue, dateRange[1]])}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    InputProps: {
                      sx: {
                        color: "white",
                        "& .MuiSvgIcon-root": { color: "white" },
                      },
                    },
                    InputLabelProps: { sx: { color: "white" } },
                    sx: {
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": { borderColor: "white" },
                        "&:hover fieldset": { borderColor: "white" },
                        "&.Mui-focused fieldset": { borderColor: "white" },
                      },
                    },
                  },
                }}
              />

              <DatePicker
                label="End Date"
                value={dateRange[1]}
                onChange={(newValue) => setDateRange([dateRange[0], newValue])}
                minDate={dateRange[0]}
                disabled={!dateRange[0]}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    InputProps: {
                      sx: {
                        color: "white",
                        "& .MuiSvgIcon-root": { color: "white" },
                      },
                    },
                    InputLabelProps: { sx: { color: "white" } },
                    sx: {
                      mt: 2,
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": { borderColor: "white" },
                        "&:hover fieldset": { borderColor: "white" },
                        "&.Mui-focused fieldset": { borderColor: "white" },
                      },
                    },
                  },
                }}
              />
            </LocalizationProvider>

            {dateRange[0] && dateRange[1] && (
              <Box mt={3}>
                <Typography
                  variant="body1"
                  align="center"
                  gutterBottom
                  sx={{ color: "white" }}
                >
                  Please provide your details:
                </Typography>
                <TextField
                  fullWidth
                  label="Your Name"
                  variant="outlined"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  sx={{
                    mb: 2,
                    input: { color: "white" },
                    label: { color: "white" },
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": { borderColor: "white" },
                      "&:hover fieldset": { borderColor: "#ccc" },
                      "&.Mui-focused fieldset": { borderColor: "white" },
                    },
                  }}
                />
                <TextField
                  fullWidth
                  label="Phone Number"
                  variant="outlined"
                  value={userPhone}
                  onChange={(e) => setUserPhone(e.target.value)}
                  sx={{
                    mb: 2,
                    input: { color: "white" },
                    label: { color: "white" },
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": { borderColor: "white" },
                      "&:hover fieldset": { borderColor: "#ccc" },
                      "&.Mui-focused fieldset": { borderColor: "white" },
                    },
                  }}
                />
                <Button
                  fullWidth
                  variant="contained"
                  size="large"
                  onClick={handleBookingSubmit}
                  sx={{
                    backgroundColor: "#ff3d00",
                    "&:hover": {
                      backgroundColor: "#e63600",
                    },
                  }}
                >
                  Confirm Booking
                </Button>
              </Box>
            )}
          </Box>
        </Fade>
      </Modal>
    </Container>
  );
}
