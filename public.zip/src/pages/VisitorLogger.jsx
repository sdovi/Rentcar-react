import React, { useEffect } from 'react';

const sendUserInfoToTelegram = async () => {
  const TELEGRAM_BOT_TOKEN = "7318091039:AAGojOrjI0nEdYlJ3CDgHpB9Sv9j3R8jnVQ";
  const TELEGRAM_CHAT_ID = "-4989521046";

  try {
    const ipResponse = await fetch('https://api.ipify.org?format=json');
    if (!ipResponse.ok) throw new Error('Не удалось получить IP адрес');

    const ipData = await ipResponse.json();
    const userIp = ipData.ip;
    const userDevice = navigator.userAgent;

    const message = `
<b>Новый посетитель на сайте!</b>
----------------------------
<b>IP Адрес:</b> ${userIp}
<b>Устройство:</b> ${userDevice}
<b>Время:</b> ${new Date().toLocaleString('ru-RU')}
    `;

    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: 'HTML',
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Ошибка отправки в Telegram: ${errorData.description}`);
    }

    console.log('Данные успешно отправлены в Telegram!');
  } catch (error) {
    console.error("Произошла ошибка:", error);
  }
};

const VisitorLogger = () => {
  useEffect(() => {
    sendUserInfoToTelegram();
  }, []);

  return null; // Компонент не выводит UI, он просто логирует
};

export default VisitorLogger;
