import React from "react";
import { useCart } from "../context/CartContext";
import CarCard from "../components/CarCard";

export default function CartPage({ lang }) {
  const { cartItems, removeFromCart } = useCart();

  if (cartItems.length === 0) {
    return <div className="main-container">Корзина пуста</div>;
  }

  return (
    <div className="main-container">
      <div className="cart-page">
        <h2 className="cart-title2">Избранное</h2>
        <div className="car-grid">
          {cartItems.map((car) => (
            <div key={car.id} className="car-card-container">
              <CarCard car={car} lang={lang} />
              
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
