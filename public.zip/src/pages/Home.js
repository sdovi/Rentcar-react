// src/pages/Home.jsx
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CarCard from '../components/CarCard';
import FilterBar from '../components/FilterBar';
import SearchBar from '../components/SearchBar';
import '../style.css';

export default function Home({ lang }) {
  const [cars, setCars] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [activeCategory, setActiveCategory] = useState('');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const ITEMS_PER_PAGE = 4;

  // Загрузка данных
  useEffect(() => {
    const fetchData = async () => {
      try {
        const apiRes = await axios.get('https://innermentorlab.com/api/cars/');
        setCars(apiRes.data);
        setFiltered(apiRes.data);
      } catch (err) {
        console.error("Ошибка загрузки данных:", err);
      }
    };

    fetchData();
  }, []);

  // Фильтрация/поиск/сортировка при изменении зависимостей
  useEffect(() => {
    let res = [...cars];

    if (activeCategory) {
      res = res.filter(car => car.category === activeCategory);
    }

    if (query.trim()) {
      res = res.filter(car => {
        const name = lang === 'ru' ? car.name_ru : car.name_en;
        return name.toLowerCase().includes(query.trim().toLowerCase());
      });
    }

    if (sort === 'asc') {
      res.sort((a, b) => a.price_per_day - b.price_per_day);
    } else if (sort === 'desc') {
      res.sort((a, b) => b.price_per_day - a.price_per_day);
    }

    setFiltered(res);
    setCurrentPage(1);
  }, [activeCategory, query, sort, cars, lang]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginatedCars = filtered.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  return (
    <div className="main-container">
      {/* Прокидываем lang в SearchBar */}
      <SearchBar
        query={query}
        setQuery={setQuery}
        lang={lang}
      />

      {/* Прокидываем lang в FilterBar */}
      <FilterBar
        active={activeCategory}
        setActive={setActiveCategory}
        sort={sort}
        setSort={setSort}
        lang={lang}
      />

      <p className="car-count">{filtered.length} машин найдено</p>

      <div className="car-grid">
        {paginatedCars.map(car => (
          <CarCard key={car.id} car={car} lang={lang} />
        ))}
      </div>

      {totalPages > 1 && (
        <div className="pagination">
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i + 1}
              onClick={() => setCurrentPage(i + 1)}
              className={`page-btn ${currentPage === i + 1 ? 'active' : ''}`}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
